####################  IMPORTS  #######################
from re import A
from tkinter import *
from tkinter import ttk
import tkinter.font as font
from subprocess import call
from unicodedata import name


####################  FUNCTIONS AND SETUP  #######################
def HOME():
    root.destroy()
    call(["python", "GUIMainDevV2.py"])



##################  CLASS CODE  ######################
class Emission():
    """In the class I have setup 3 variables that are taken into consideration when calculating your average emission; transport, energy like electricity and household waste """
    """max means the maximum emission the should have"""
    def __init__(self, name, total, max):
        self.name = name
        self.max = float(max)
        self.total = float(total)
        emission_list.append(self)

    #calculate hotwater co2 usage
    """If showered add the amount of hotwater used times the time by 9ltrs per min avg water output of a shower head."""
    """ Add any other hot water used and then times that by carbon output for 1ltr of hot water"""
    def hotwater(self, amount):
        if amount > 0:
            amount *= 2.682
            self.total += amount
            return True
        else:
           return False


    #calculate vehicle co2 usage
    def vehicle(self, amount):
        if amount > 0:
            amount *= 359
            self.total += amount
            return True
        else:
            return False
       
    #calculate energy co2 usage
    def energy(self, amount):
        if amount > 0:
            amount *= 0.72
            self.total += amount
            return True
        else:
            return False
    


####################  FUNCTIONS AND SETUP  #######################
def create_name_list():
    factor_list = []
    for emission in emission_list:
        factor_list.append(emission.name)
    return factor_list


def ev_hotwater(name):
    if name.hotwater(amount.get()):
        action_feedback.set("Valid Input")
    else:
        action_feedback.set("Please enter a positive number")

def ev_vehicle(name):
  if name.vehicle(amount.get()):
    action_feedback.set("Valid Input")
  else:
    action_feedback.set("Please enter a positive number")

def ev_energy(name):
  if name.energy(amount.get()):
    action_feedback.set("Valid Input")
  else:
    action_feedback.set("Please enter a positive number")


def update_final_emission():
    final_emission = 0
    emission_string = ""
    for emission in emission_list:
        final_emission += emission.total
        emission_string += "You're carbon footprint is {:.2f} grams today for {}\n".format(emission.total, emission.name)
    maxemission = 19000
    global percentage
    percentage = 0
    percentage += (final_emission / maxemission) * 100
    emission_string += "\n Total carbon you have emitted today is {:.2f}\n You have hit {:.2f}% of the recommemded carbon emission".format(final_emission, percentage)
    emission_details.set(emission_string)
    amount_of_emission = ""
    if percentage <= 50:
        if percentage >=15:
            amount_of_emission += "Wow your emission is really low keep it up!"
        else:
            amount_of_emission += "Nice to see that you are keeping your emission's to a minimal!"
    elif percentage <= 100:   
        if percentage <= 75:
            amount_of_emission += "You are doing good! Lets try lowering it more if you can!"
        else:
            amount_of_emission += "Think about lowering your emissions if possible still not too bad!"
    else:
        amount_of_emission += "You have got something else to focus on now as well"
    emission_response.set(amount_of_emission)


def manage_action():
    try:
        if int(amount_entry.get()):
            for emission in emission_list:
                if chosen_action == emission.name:
                    if chosen_action == "Vehicle":
                        ev_vehicle(emission)
                    elif chosen_action == "Hot Water":
                        ev_hotwater(emission)
                    else:
                        ev_energy(emission)

            update_final_emission()
            amount.set("")
    except ValueError:
        action_feedback.set("Please enter a Valid Number")
    
#list of emissions
emission_list = []

#setup the instances in this case type of emissions under the Emission 
Vehicle = Emission("Vehicle", 0, 13000)
Water = Emission("Hot Water", 0,  13000)
Energy = Emission("Energy", 0,  13000)

emission_names = create_name_list()

def comboclick(event):
    global chosen_action
    chosen_action = action_box.get()

chosen_action = 'Vehicle'



#################### GUI CODE  #######################
root = Tk()
root.title("Calculator")
root.configure(bg="Light Blue")

logo = PhotoImage(file="img/FINAL/Logo.png")

homebutton = Button(root, image=logo, bg="light blue", borderwidth=0, activebackground="#88b589", command=HOME)  # logo imported as a Label
homebutton.grid(row=1, column=0, columnspan=2, padx=1, pady=1)  # position of label

#Creating font style's for GUI
Heading = font.Font(weight="bold", size=12, slant="italic", underline= True)
TopBody = font.Font(weight="bold", size=10, slant="italic")
Body = font.Font(size=10)
CWtext = font.Font(weight="bold", size = 9)

# Create the top frame
top_frame = LabelFrame(root, text="Emission Details", bg="Light Blue", borderwidth=0)
top_frame.grid(row=2, column=0, padx=10, pady=10, sticky="NSEW")
top_frame['font'] = Heading 

# Create and set the message text variable
message_text = StringVar()
message_text.set("This is our CO2 Calculator. Please enter Values in terms of Kilometers (km) or Hours (h)")

# Create and pack the message label
message_label = Label(top_frame, textvariable=message_text, wraplength=250, bg="Light Blue")
message_label.grid(row=0, column=0, columnspan=2, padx=10, pady=10)
message_label['font'] = TopBody
# Create and set the account details variable
emission_details = StringVar()
# Create the details label and pack it into the GUI
details_label = Label(top_frame, textvariable=emission_details, bg="Light Blue")
details_label.grid(row=2, column=0, columnspan=2, padx=10, pady=10)
details_label['font'] = Body
#Create a text label taht reacts to the amount of CO2 emitted
emission_response = StringVar()
response_label = Label(top_frame, textvariable=emission_response, bg="Light Blue")
response_label.grid(row=3, column=0, columnspan=2, padx=5)
response_label['font'] = Body
# Create the bottom frame
bottom_frame = LabelFrame(root, bg="Light Blue", borderwidth=0)
bottom_frame.grid(row=3, column=0, padx=10, pady=10, columnspan=5)

# Create a label for the action Combobox
action_label = Label(bottom_frame, text="Input:", bg="Light Blue")
action_label.grid(row=4, column=0)
action_label['font'] = Body
# Set up a variable and option list for the action Combobox
"""
subaction_list = ["Vehicle", "Hot Water", "Energy"]
subchosen_action = StringVar()
subchosen_action.set(subaction_list[0])
"""

# Create the Combobox to select the action
"""
action_box = ttk.Combobox(bottom_frame, textvariable=subchosen_action, state="readonly")
action_box['values'] = subaction_list
action_box.grid(row=4, column=1, padx=10, pady=3, sticky="WE")
"""
# Set up a variable and option list for the action Combobox
action_list = ["Vehicle", "Hot Water", "Energy"]
print(chosen_action)


# Create the Combobox to select the action
action_box = ttk.Combobox(bottom_frame, state="readonly")
action_box['values'] = action_list
action_box.current(0)
action_box.bind('<<ComboboxSelected>>', comboclick)
action_box.grid(row=4, column=1, padx=10, pady=3, sticky="NSEW")


# Create a label for the amount field and pack it into the GUI
amount_label = Label(bottom_frame, text= "Amount(Km/Hrs):", bg="Light Blue")
amount_label.grid(row=5, column=0, padx=15, pady=3)
amount_label['font'] = Body
# Create a variable to store the amount
amount = DoubleVar()
amount.set("")

# Create an entry to type in amount
amount_entry = Entry(bottom_frame, textvariable=amount, bg="#88b589")
amount_entry.grid(row=5, column=1, padx=10, pady=3, sticky="NSEW")

# Create a submit button
submit_button = Button(bottom_frame, text="Submit", command=manage_action, bg="Light Blue", activebackground="#88b589")
submit_button.grid(row=6, column=0, padx=10, pady=10, columnspan=2)
submit_button['font'] = Body
# Create an action feedback label
action_feedback = StringVar()
action_feedback_label = Label(bottom_frame, textvariable=action_feedback, bg="Light Blue")
action_feedback_label.grid(row=7, column=0, columnspan=2, padx=20, pady=10, sticky="NSEW")
action_feedback_label['font'] = Body
# Create copywright label
copyright = Label(root, text="\u00A9 BigFoot EST 2022. Coded by Praful Patel", bg="light blue")
copyright.grid(row=9, column=0, padx=10, pady=1) 
copyright['font'] = CWtext

# Run the mainloop and call functions required
update_final_emission()
root.mainloop()