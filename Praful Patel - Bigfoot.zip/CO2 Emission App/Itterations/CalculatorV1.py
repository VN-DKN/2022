####################  IMPORTS  #######################
from tkinter import *
from tkinter import ttk
from subprocess import call
import time

####################  FUNCTIONS AND SETUP  #######################
def HOME():
    window.destroy()
    call(["python", "GUIMainDevV2.py"])
    print("Calculator Closed")


#################### GUI CODE  #######################
window = Tk()
window.title("Welcome")
window.geometry('600x600')  # the windows parameters
window.configure(bg="light blue")
    
logo = PhotoImage(file="C:/Users/prboy/Desktop/School Shit/Digital Tech/LEVEL 3/CO2 Emission App/img/FINAL/Logo.png")
homebutton = Button(window, image=logo, bg="light blue", borderwidth=0, activebackground="#88b589", command=HOME)  # logo imported as a Label
homebutton.place(relx=0.5, rely=0.28, anchor=CENTER)  # position of label

copyright = Label(text="\u00A9 BigFoot EST 2022. Coded by Praful Patel", bg="light blue")
copyright.place(relx=0.5, rely=0.98, anchor=CENTER) 

