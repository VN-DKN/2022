####################  IMPORTS  #######################
from tkinter import *
from tkinter import ttk
import random
####################  CLASS CODE  #######################
####################  FUNCTIONS AND SETUP  #######################
####################  GUI CODE  #######################
window = Tk()

window.title("Welcome")
window.geometry('600x800')  # the windows parameters
banner = Label(window, text="logo")  # asks for their name
banner.place(relx=0.5, rely=0.1, anchor=CENTER)  # position of label
start = Button(window, width=30, height=10, pady= 10, padx=10, text="Calculate")  # entry box for users name
start.place(relx=0.5, rely=0.3, anchor=CENTER)  # poison of entry box
info = Button(window, width=30, height=10, pady=10, padx= 10, text= "Information")
info.place(relx= 0.5, rely=0.8, anchor=CENTER)


window.mainloop()