####################  IMPORTS  #######################
from re import A
from tkinter import *
from tkinter import ttk
from subprocess import call
import random
from unicodedata import name


####################  FUNCTIONS AND SETUP  #######################
def HOME():
    window.destroy()
    call(["python", "GUIMainDevV2.py"])



##################  CLASS CODE  ######################
class Emission():
    """In the class I have setup 3 variables that are taken into consideration when calculating your average emission; transport, energy like electricity and household waste """
    """max means the maximum emission the should have"""
    def __init__(self, name, total, max):
        self.name = name
        self.max = float(max)
        self.total = float(total)
        emission_list.append(self)

    #calculate hotwater co2 usage
    """If showered add the amount of hotwater used times the time by 9ltrs per min avg water output of a shower head."""
    """ Add any other hot water used and then times that by carbon output for 1ltr of hot water"""
    def hotwater(self, amount):
        if amount > 0:
            amount *= 2.682
            self.total += amount
            return True
        else:
           return False


    #calculate vehicle co2 usage
    def vehicle(self, amount):
        if amount > 0:
            amount *= 122.1
            self.total += amount
            return True
        else:
            return False
       
    #calculate energy co2 usage
    def energy(self, amount):
        if amount > 0:
            amount *= 0.72
            self.total += amount
            return True
        else:
            return False

####################  FUNCTIONS AND SETUP  #######################
def create_name_list():
    factor_list = []
    for emission in emission_list:
        factor_list.append(emission.name)
    return factor_list


def ev_hotwater(name):
    if name.hotwater(amount.get()):
        action_feedback.set("Valid Input")
    else:
        action_feedback.set("Please enter a positive number")

def ev_vehicle(name):
  if name.vehicle(amount.get()):
    action_feedback.set("Valid Input")
  else:
    action_feedback.set("Please enter a positive number")

def ev_energy(name):
  if name.energy(amount.get()):
    action_feedback.set("Valid Input")
  else:
    action_feedback.set("Please enter a positive number")

def update_final_emission():
    final_emission = 0
    emission_string = ""
    for emission in emission_list:
        final_emission += emission.total
        emission_string += "You're carbon footprint is {:.2f} grams today for {}\n".format(emission.total, emission.name)
    
    emission_string += "Total carbon you have emitted today is {:.2f}".format(final_emission)
    emission_details.set(emission_string)

def manage_action():
    try:
        if int(amount_entry.get()):
            for emission in emission_list:
                if chosen_action == emission.name:
                    if chosen_action == "Vehicle":
                        ev_vehicle(emission)
                    elif chosen_action == "Hot Water":
                        ev_hotwater(emission)
                    else:
                        ev_energy(emission)

            update_final_emission()
            amount.set("")
    except ValueError:
        action_feedback.set("Please enter a Valid Number")
    
#list of emissions
emission_list = []

#setup the instances in this case type of emissions under the Emission 
Vehicle = Emission("Vehicle", 0, 13000)
Water = Emission("Hot Water", 0,  13000)
Energy = Emission("Energy", 0,  13000)

emission_names = create_name_list()

def comboclick(event):
    global chosen_action
    chosen_action = action_box.get()

chosen_action = 'Vehicle'

#################### GUI CODE  #######################
root = Tk()
root.title("Goal Tracker")

# Create the top frame
top_frame = ttk.LabelFrame(root, text="Emission Details")
top_frame.grid(row=2, column=0, padx=10, pady=10, sticky="NSEW")

# Create and set the message text variable
message_text = StringVar()
message_text.set("Our CO2 Calculator. Please enter Values in terms of Kilometers (km) or Hours (h)")

# Create and pack the message label
message_label = ttk.Label(top_frame, textvariable=message_text, wraplength=250)
message_label.grid(row=0, column=0, columnspan=2, padx=10, pady=10)

# Create the PhotoImage and label to hold it
neutral_image = PhotoImage(file="img/FINAL/Logo.png")

image_label = ttk.Label(root, image=neutral_image)
image_label.grid(row=1, column=0, columnspan=2, padx=10, pady=10)

# Create and set the account details variable
emission_details = StringVar()
# Create the details label and pack it into the GUI
details_label = ttk.Label(top_frame, textvariable=emission_details)
details_label.grid(row=2, column=0, columnspan=2, padx=10, pady=10)

# Create the bottom frame
bottom_frame = ttk.LabelFrame(root)
bottom_frame.grid(row=3, column=0, padx=10, pady=10, sticky="NSEW")

# Create a label for the action Combobox
action_label = ttk.Label(bottom_frame, text="Input:")
action_label.grid(row=4, column=0)

# Set up a variable and option list for the action Combobox
"""
subaction_list = ["Vehicle", "Hot Water", "Energy"]
subchosen_action = StringVar()
subchosen_action.set(subaction_list[0])
"""

# Create the Combobox to select the action
"""
action_box = ttk.Combobox(bottom_frame, textvariable=subchosen_action, state="readonly")
action_box['values'] = subaction_list
action_box.grid(row=4, column=1, padx=10, pady=3, sticky="WE")
"""
# Set up a variable and option list for the action Combobox
action_list = ["Vehicle", "Hot Water", "Energy"]
print(chosen_action)


# Create the Combobox to select the action
action_box = ttk.Combobox(bottom_frame, state="readonly")
action_box['values'] = action_list
action_box.current(0)
action_box.bind('<<ComboboxSelected>>', comboclick)
action_box.grid(row=4, column=1, padx=10, pady=3, sticky="NSEW")


# Create a label for the amount field and pack it into the GUI
amount_label = ttk.Label(bottom_frame, text= "Amount(Km/Hrs):")
amount_label.grid(row=5, column=0, padx=10, pady=3)

# Create a variable to store the amount
amount = DoubleVar()
amount.set("")

# Create an entry to type in amount
amount_entry = ttk.Entry(bottom_frame, textvariable=amount)
amount_entry.grid(row=5, column=1, padx=10, pady=3, sticky="NSEW")

# Create a submit button
submit_button = ttk.Button(bottom_frame, text="Submit", command=manage_action)
submit_button.grid(row=6, column=0, columnspan=2, padx=10, pady=10)

# Create an action feedback label
action_feedback = StringVar()
action_feedback_label = ttk.Label(bottom_frame, textvariable=action_feedback)
action_feedback_label.grid(row=7, column=0, columnspan=2)

# Run the mainloop
update_final_emission()
root.mainloop()
