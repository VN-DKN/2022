####################  IMPORTS  #######################
from tkinter import *
from tkinter import ttk
from subprocess import call
import tkinter.font as font
import webbrowser
####################  FUNCTIONS AND SETUP  #######################
window = Tk()
window.title("Info")
window.geometry('360x600')  # the windows parameters
window.configure(bg="light blue")

def HOME():
    window.destroy()
    call(["python", "GUIMainDevV2.py"])

def callback(url):
    webbrowser.open_new(url)

info = str("Bigfoot has an aimable goal to help its end\n users reduce their CO2 output.\n"
"Bigfoot wants to achieve this by helping\n them track their CO2 output at the\n end of each day to see how they did.\n"
" This is projected to help many end users\n"
"to help save the planet each day by making\n it a prominant thought they have each day\n")

Body = font.Font(weight="normal", size=10)
Link = font.Font(weight="bold", size=10, slant="italic")
CWtext = font.Font(weight="bold", size = 9)

info_string = Label(text=info, bg= "light blue")
info_string.place(relx=0.5, rely= 0.7, anchor=CENTER)
info_string['font'] = Body

logo = PhotoImage(file="/img/FINAL/Logo.png")
homebutton = Button(window, image=logo, bg="light blue", borderwidth=0, activebackground="#88b589", command=HOME)  # logo imported as a Label
homebutton.place(relx=0.5, rely=0.28, anchor=CENTER)  # position of label

btn = Button(window, text = "Click this to help you reduce\n your CO2 emissions.", borderwidth=0, background="#88b589")
btn.place(relx=0.5, rely=0.9, anchor=CENTER)
btn.bind("<Button 1>", lambda e: callback("https://europa.eu/youth/get-involved/sustainable-development/how-reduce-my-carbon-footprint_en"))
btn['font'] = Link

copyright = Label(text="\u00A9 BigFoot EST 2022. Coded by Praful Patel", bg="light blue")
copyright.place(relx=0.5, rely=0.98, anchor=CENTER) 
copyright['font'] = CWtext



window.mainloop()