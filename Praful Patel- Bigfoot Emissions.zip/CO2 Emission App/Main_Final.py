####################  IMPORTS  #######################
from tkinter import *
from tkinter import ttk
import time
from subprocess import call
import tkinter.font as font

####################  FUNCTIONS AND SETUP  #######################
# Create defs to open the other pages using call function
def calculator():
    print("Calculator opened")
    window.destroy()
    call(["python", "Calculator_Final.py"])

def info():
    print("Info opened")
    window.destroy()
    call(["python", "Info_Final.py"])


####################  GUI CODE  #######################
window = Tk()
window.title("Main Menu")
window.geometry('360x600')  # the windows parameters
window.configure(bg="light blue")

#Font for copywright label text
CWtext = font.Font(weight="bold", size =9)

#Add logo as a label on homepage instead of button
logo = PhotoImage(file="img/FINAL/Logo.png")
logoinput = Label(window, image=logo, bg="light blue")  # logo imported as a Label
logoinput.place(relx=0.5, rely=0.28, anchor=CENTER)  # position of label

#Button to take me to calculator page
calc_img = PhotoImage(file="img/FINAL/Calculator.png")
calc_button = Button(window, pady= 10, padx=10, image= calc_img, command=calculator, bg="light blue", activebackground="#88b589", borderwidth=0)  #button for the calculator window to open
calc_button.place(relx=0.2, rely=0.75, anchor=CENTER)  # position of the button

#Button to take you to info page
infobutton = PhotoImage(file="img/FINAL/Info.png")
info_button = Button(window, pady=10, padx= 10, image=infobutton, command=info, bg="light blue", activebackground="#88b589", borderwidth=0) # button for info window to open
info_button.place(relx= 0.75, rely=0.74, anchor=CENTER) #position of the button

#create label for copyright text
copyright = Label(text="\u00A9 BigFoot EST 2022. Coded by Praful Patel", bg="light blue")
copyright.place(relx=0.5, rely=0.98, anchor=CENTER) 
copyright['font'] = CWtext

window.mainloop()
